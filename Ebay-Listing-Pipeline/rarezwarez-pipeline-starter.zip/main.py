import os
import io
import json
import time
import zipfile
import traceback
import gc
from flask import Flask
from google.cloud import storage
from googleapiclient.discovery import build
from google import genai
from google.auth import default
from rembg import remove
from PIL import Image, ImageStat
from datetime import datetime, timezone, timedelta
from urllib.parse import quote_plus

app = Flask(__name__)

SHEET_ID = os.environ.get("SHEET_ID")
BUCKET_NAME = os.environ.get("BUCKET_NAME")
OUTPUT_BUCKET_NAME = os.environ.get("OUTPUT_BUCKET_NAME")

LOCK_BLOB_NAME = "_processing.lock"
LOCK_STALE_AFTER = timedelta(minutes=5)

# Sanity cap: if a divider between two items is ever misclassified as "not
# blackout", the scan would otherwise keep absorbing photos past the item
# boundary and merge multiple items into one listing. This bounds the blast
# radius when that happens instead of silently combining everything.
MAX_PHOTOS_PER_ITEM = 10

# --- AUTHENTICATION WIRING ---
credentials, project = default(scopes=[
    'https://www.googleapis.com/auth/spreadsheets',
    'https://www.googleapis.com/auth/cloud-platform'
])

sheets_service = build('sheets', 'v4', credentials=credentials)
storage_client = storage.Client(credentials=credentials)

# Upgraded to the new genai SDK
ai_client = genai.Client(api_key=os.environ.get("GEMINI_API_KEY"))

def get_brightness_stats(raw_bytes):
    # Convert to grayscale, shrink to 50x50 to process instantly
    img = Image.open(io.BytesIO(raw_bytes)).convert('L')
    img.thumbnail((50, 50))
    stat = ImageStat.Stat(img)
    # mean: 0 is pitch black, 255 is pure white. stddev: how much texture/edge
    # variation exists in the frame.
    return stat.mean[0], stat.stddev[0]

def is_blackout_photo(mean_brightness, stddev):
    # Primary rule: dark on average (threshold raised to 60 to account for
    # light bleed and auto-exposure).
    # Secondary rule: some phones (especially "NIGHT_"-prefixed auto
    # night-mode shots) brighten a covered lens above that threshold, but a
    # covered lens still has almost no texture compared to a real item, so a
    # low stddev catches false negatives that brightness alone misses.
    return mean_brightness < 60 or (mean_brightness < 100 and stddev < 12)

LISTING_SCHEMA = {
    "type": "OBJECT",
    "properties": {
        "Title": {"type": "STRING"},
        "Condition": {"type": "STRING"},
        "Description": {"type": "STRING"},
        "Estimated_Value": {"type": "STRING"},
        "Estimated_Shipping": {"type": "STRING"},
    },
    "required": ["Title", "Condition", "Description", "Estimated_Value", "Estimated_Shipping"],
}

def generate_listing(image_bytes_list):
    prompt = """
    You are a professional eBay warehouse inspector and expert copywriter.
    Analyze the item in the image for resale.
    Return ONLY a JSON dictionary with these five keys:
    1. "Title": An 80-character SEO optimized eBay title.
    2. "Condition": Inspect for and explicitly mention any visible scuffs, rips, tears, stains, or missing pieces. If none are visible, state "Excellent pre-owned condition".
    3. "Description": Write a professional, bulleted description under 150 words. Repeat the condition. Include any dimensions visually confirmed in the photos. If the item is a part or incomplete part of a set, explicitly list the compatible models or items.
       End the description with exactly this text:
       *** Shipping carrier may vary based on buyer location. Packaging may be recycled or original manufacturer packaging may be reused. ***
    4. "Estimated_Value": A realistic secondary-market price estimate (in USD) based on the brand, item type, and condition.
    5. "Estimated_Shipping": The estimated shipping weight and box dimensions (e.g., '1 lb 4 oz, 10x8x6').
    """

    # Build a list containing the prompt string AND all the images
    contents = [prompt]
    for raw_bytes in image_bytes_list:
        contents.append(Image.open(io.BytesIO(raw_bytes)))

    # response_schema pins the model to exactly these five string fields, so it
    # can't wander into malformed output (e.g. stray trailing characters/braces
    # after a valid object, which is what broke the "Extra data" parse earlier).
    response = ai_client.models.generate_content(
        model='gemini-3.5-flash',
        contents=contents,
        config={
            "response_mime_type": "application/json",
            "response_schema": LISTING_SCHEMA,
        }
    )
    return response.text

def save_assets(title, condition, description, estimated_value, estimated_shipping, zip_buffer):
    output_bucket = storage_client.bucket(OUTPUT_BUCKET_NAME)
    
    safe_title = "".join([c for c in title[:40] if c.isalnum() or c==' ']).rstrip().replace(' ', '_')
    zip_file_name = f"{safe_title}_{int(time.time())}.zip"
    
    blob = output_bucket.blob(zip_file_name)
    blob.upload_from_string(zip_buffer.getvalue(), content_type='application/zip')
    zip_url = f"https://storage.googleapis.com/{OUTPUT_BUCKET_NAME}/{zip_file_name}"

    # Links to eBay's own "completed + sold" listings search for the generated
    # title, so the AI's Estimated_Value can be sanity-checked against real
    # comps with one click. Same filters (LH_Complete=1&LH_Sold=1) eBay's UI
    # sets when you search then tick "Sold items" - no scraping/API involved.
    comps_url = f"https://www.ebay.com/sch/i.html?_nkw={quote_plus(title)}&LH_Complete=1&LH_Sold=1"

    body = {
        'values': [[
            datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M"),
            title, condition, description, estimated_value, estimated_shipping, zip_url, comps_url
        ]]
    }
    sheets_service.spreadsheets().values().append(
        spreadsheetId=SHEET_ID, range="Sheet1!A:H",
        valueInputOption="USER_ENTERED", body=body).execute()

@app.route('/run-batch', methods=['GET', 'POST'])
def run_batch_processor():
    bucket = storage_client.bucket(BUCKET_NAME)
    lock_blob = bucket.blob(LOCK_BLOB_NAME)

    # --- CONCURRENCY GUARD ---
    # Cloud Scheduler fires every minute regardless of whether the previous
    # invocation has finished. Without a lock, two overlapping runs can each
    # grab overlapping photos into different groups (or race each other's
    # deletes), which produces the exact same "mixed items" symptom as a
    # missed divider. This uses if_generation_match=0 for an atomic
    # create-if-absent lock in GCS.
    try:
        lock_blob.upload_from_string(
            datetime.now(timezone.utc).isoformat(), if_generation_match=0
        )
    except Exception:
        lock_blob.reload()
        if lock_blob.time_created and (datetime.now(timezone.utc) - lock_blob.time_created) < LOCK_STALE_AFTER:
            return "Already processing. Skipping this tick.", 200
        # Lock is older than LOCK_STALE_AFTER - a previous run likely crashed
        # without releasing it. Reclaim it rather than staying stuck forever.
        lock_blob.upload_from_string(datetime.now(timezone.utc).isoformat())

    try:
        all_blobs = list(bucket.list_blobs())
        blobs = [b for b in all_blobs if b.name.lower().endswith(('.png', '.jpg', '.jpeg', '.webp'))]

        for b in all_blobs:
            if b not in blobs and b.name != LOCK_BLOB_NAME:
                b.delete()

        if not blobs:
            return "Empty bucket or no valid images", 200

        # Safety Net: Wait until FolderSync is completely done uploading
        newest_blob = max(blobs, key=lambda b: b.time_created)
        if (datetime.now(timezone.utc) - newest_blob.time_created) < timedelta(seconds=30):
            return "Sync active. Waiting.", 200
            
        # Sort purely by the timestamp digits in the filename, ignoring text prefixes like 'IMG_' or 'NIGHT_'
        sorted_blobs = sorted(blobs, key=lambda b: int(''.join(filter(str.isdigit, b.name)) or 0))
        group_to_process = []
        dividers_to_delete = []
        
        # --- THE BLACKOUT SCANNER ---
        for blob in sorted_blobs:
            raw_bytes = blob.download_as_bytes()
            mean_brightness, stddev = get_brightness_stats(raw_bytes)
            print(f"BLACKOUT_SCAN name={blob.name} mean={mean_brightness:.1f} stddev={stddev:.1f}")

            if is_blackout_photo(mean_brightness, stddev):
                dividers_to_delete.append(blob)
                del raw_bytes
                gc.collect()
                if len(group_to_process) > 0:
                    # We hit a blackout photo and we have a group! Stop scanning.
                    break
            else:
                group_to_process.append(blob)
                del raw_bytes
                gc.collect()
                if len(group_to_process) >= MAX_PHOTOS_PER_ITEM:
                    print(f"BLACKOUT_SCAN WARNING: hit {MAX_PHOTOS_PER_ITEM}-photo cap without finding "
                          f"a divider after '{blob.name}'. A blackout photo was likely missed - stopping "
                          f"the group early instead of merging further items.")
                    break

        # Clean up any blackout photos we passed so they don't clog the bucket
        for d in dividers_to_delete:
            d.delete()

        if not group_to_process:
            return "Only dividers found.", 200

        # --- PROCESS THE SINGLE ITEM ---
        
        # 1. Grab up to the first 4 photos to send to the AI
        ai_analysis_bytes = []
        # group_to_process[:4] safely grabs the first 4. If there are only 2 photos, it grabs 2.
        for blob in group_to_process[:4]:
            ai_analysis_bytes.append(blob.download_as_bytes())

        # 2. Ask Gemini for the text using the multi-image list
        listing_data_raw = generate_listing(ai_analysis_bytes) 
        
        # 3. Parse the text using your relaxed parser
        try:
            clean_json = listing_data_raw.replace('```json', '').replace('```', '').strip()
            # raw_decode (vs. json.loads) only requires a valid JSON object at
            # the START of the string - it ignores trailing extra data instead
            # of failing the whole parse over it (e.g. a stray closing brace
            # after an otherwise-complete object).
            data, _ = json.JSONDecoder(strict=False).raw_decode(clean_json)
            title = data.get("Title", "Generated Title")
            condition = data.get("Condition", "Used")
            description = data.get("Description", "See photos")
            estimated_value = data.get("Estimated_Value", "N/A")
            estimated_shipping = data.get("Estimated_Shipping", "N/A")
        except Exception:
            print(f"LISTING_PARSE_ERROR raw_response={listing_data_raw!r}")
            title, condition, description = "Error Parsing Title", "Unknown", str(listing_data_raw)
            estimated_value, estimated_shipping = "Error", "Error"

        # 4. Build the ZIP file
        zip_buffer = io.BytesIO()
        with zipfile.ZipFile(zip_buffer, 'a', zipfile.ZIP_DEFLATED, False) as zip_file:
            for i, blob in enumerate(group_to_process):
                raw_bytes = blob.download_as_bytes()
                
                if i == 0:
                    # Remove background for the primary photo ONLY
                    final_bytes = remove(raw_bytes)
                    photo_name = f"photo_1_main.png"
                else:
                    final_bytes = raw_bytes
                    ext = os.path.splitext(blob.name)[1].lower()
                    if not ext: ext = '.jpg'
                    photo_name = f"photo_{i+1}_raw{ext}"
                
                zip_file.writestr(photo_name, final_bytes)
                del raw_bytes
                del final_bytes
                gc.collect() 

        # 5. Save everything to Sheets and Output Bucket
        save_assets(title, condition, description, estimated_value, estimated_shipping, zip_buffer)
            
        # 6. Clean up original raw photos from the processing bucket
        for b in group_to_process:
            b.delete()

        return f"Processed 1 item ({len(group_to_process)} photos). Resuming next tick.", 200

    except Exception as e:
        error_trace = traceback.format_exc()
        return f"CRITICAL ERROR DETECTED:\n\n{error_trace}", 500
    finally:
        # Always release the lock, on every return path and on error, so a
        # single failed run can't wedge the bucket shut for LOCK_STALE_AFTER.
        lock_blob.delete()

@app.route('/reset-sheet', methods=['GET'])
def reset_sheet():
    # Updated to clear up to column H to match the new layout
    sheets_service.spreadsheets().values().clear(
        spreadsheetId=SHEET_ID, range="Sheet1!A2:H1000").execute()
    return "Inventory Sheet has been wiped clean!", 200

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=int(os.environ.get('PORT', 8080)))